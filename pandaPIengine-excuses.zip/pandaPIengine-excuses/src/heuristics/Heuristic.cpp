//
// Created by dh on 29.03.21.
//

#include "Heuristic.h"

Heuristic::Heuristic(Model *htnModel, int index) {
	this->htn = htnModel;
 	this->index = index;
}
