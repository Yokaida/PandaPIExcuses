//
// Created by dh on 31.03.21.
//

#ifndef PANDAPIENGINE_HHLMPAYLOAD_H
#define PANDAPIENGINE_HHLMPAYLOAD_H

#include "../HeuristicPayload.h"

class hhLMPayload : HeuristicPayload {

};


#endif //PANDAPIENGINE_HHLMPAYLOAD_H
