#ifndef AUTOMATON_H_
#define AUTOMATON_H_

#include "../Model.h"


void build_automaton(Model * htn);


#endif 

