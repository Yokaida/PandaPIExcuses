#ifndef INTERACTIVE_PLANNER
#define INTERACTIVE_PLANNER

#include "flags.h" // defines flags
#include "Model.h"


void interactivePlanner(Model* htn, searchNode* tnI);

#endif
